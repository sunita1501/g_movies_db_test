package com.galvanize.cognizant.Cyptozoology;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CyptozoologyApplicationTests {

	@Test
	void contextLoads() {
	}

}
