package com.galvanize.cognizant.Cyptozoology;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyptozoologyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CyptozoologyApplication.class, args);
	}

}
